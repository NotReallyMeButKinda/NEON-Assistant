// NEON Assistant Bridge -- the browser half of browser_bridge.py.
//
// NEON can't call into the browser, so this keeps one long-poll open to NEON on 127.0.0.1 ("anything
// for me?"). When NEON answers with a request ("the page you're on", "your tabs"), it is carried out
// here and the result is posted back. Nothing is sent anywhere else, and nothing is sent unless NEON
// asks for it.

"use strict";

const DEFAULTS = { port: 47811, token: "" };
const MAX_TEXT = 60000;          // characters of page text sent for one page
const UNREADABLE = /^(about:|moz-extension:|view-source:|chrome:|resource:|https:\/\/addons\.mozilla\.org)/;

let state = "off";               // off | on | key (NEON is there but the token is wrong)

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function settings() {
  const stored = await browser.storage.local.get(DEFAULTS);
  return { port: Number(stored.port) || DEFAULTS.port, token: String(stored.token || "").trim() };
}

function show(next) {
  if (next === state) return;
  state = next;
  const badge = { on: "", off: "off", key: "key" }[next];
  const title = {
    on: "NEON: connected",
    off: "NEON: not connected (is NEON running?)",
    key: "NEON: wrong token -- paste it from NEON's Settings > Browser",
  }[next];
  browser.browserAction.setBadgeText({ text: badge });
  browser.browserAction.setBadgeBackgroundColor({ color: next === "key" ? "#d9822b" : "#555555" });
  browser.browserAction.setTitle({ title });
}

// ---- reading a page (runs inside the page) -----------------------------------------------------

function extractPage(maxChars) {
  const meta = (name) => {
    const el = document.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
    return el ? String(el.content || "").trim() : "";
  };
  const selection = String(window.getSelection ? window.getSelection() : "").trim();
  const candidates = ["article", "main", "[role=main]", "#content", "#main", ".content"];
  let root = null;
  for (const sel of candidates) {
    const el = document.querySelector(sel);
    if (el && (el.innerText || "").trim().length > 400) { root = el; break; }
  }
  let text = ((root || document.body || {}).innerText || "").trim();
  if (root && document.body && text.length < 1500) text = (document.body.innerText || "").trim();
  text = text.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").slice(0, maxChars);

  const headings = Array.from(document.querySelectorAll("h1, h2, h3"))
    .map((h) => (h.innerText || "").trim()).filter(Boolean).slice(0, 40);

  const pick = (obj, key) => {
    const v = obj ? obj[key] : undefined;
    if (v === undefined || v === null) return undefined;
    if (Array.isArray(v)) return v.map((x) => (typeof x === "object" ? x.name || x["@id"] || "" : String(x)))
      .filter(Boolean).slice(0, 6).join(", ");
    if (typeof v === "object") return v.name || v["@value"] || undefined;
    return String(v).slice(0, 300);
  };
  const structured = [];
  for (const script of document.querySelectorAll('script[type="application/ld+json"]')) {
    let data;
    try { data = JSON.parse(script.textContent); } catch (e) { continue; }
    const items = [].concat(Array.isArray(data) ? data : (data && data["@graph"]) || [data]);
    for (const item of items) {
      if (!item || typeof item !== "object") continue;
      const offers = Array.isArray(item.offers) ? item.offers[0] : item.offers;
      const rating = item.aggregateRating;
      const entry = {
        type: pick(item, "@type"), name: pick(item, "name") || pick(item, "headline"),
        author: pick(item, "author"), brand: pick(item, "brand"), director: pick(item, "director"),
        publisher: pick(item, "publisher"), datePublished: pick(item, "datePublished"),
        releaseDate: pick(item, "releaseDate"), startDate: pick(item, "startDate"),
        genre: pick(item, "genre"), platform: pick(item, "gamePlatform"), duration: pick(item, "duration"),
        price: offers ? pick(offers, "price") || pick(offers, "lowPrice") : undefined,
        currency: offers ? pick(offers, "priceCurrency") : undefined,
        availability: offers ? pick(offers, "availability") : undefined,
        rating: rating ? pick(rating, "ratingValue") : undefined,
        ratingCount: rating ? pick(rating, "ratingCount") || pick(rating, "reviewCount") : undefined,
        description: pick(item, "description"),
      };
      for (const k of Object.keys(entry)) if (entry[k] === undefined || entry[k] === "") delete entry[k];
      if (Object.keys(entry).length > 1) structured.push(entry);
      if (structured.length >= 12) break;
    }
  }
  return {
    title: document.title || "", url: location.href,
    description: meta("description") || meta("og:description"),
    selection: selection.slice(0, 20000), headings, text, structured,
    lang: document.documentElement.lang || "",
  };
}

// ---- carrying out NEON's requests --------------------------------------------------------------

async function activeTab() {
  const [tab] = await browser.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab) throw new Error("there's no open tab");
  return tab;
}

function tabInfo(tab) {
  return { id: tab.id, title: tab.title || "", url: tab.url || "", active: !!tab.active,
           windowId: tab.windowId, audible: !!tab.audible, pinned: !!tab.pinned };
}

async function readPage(tab) {
  if (UNREADABLE.test(tab.url || "")) throw new Error("the browser doesn't let extensions read this page");
  const [page] = await browser.tabs.executeScript(tab.id, {
    code: `(${extractPage.toString()})(${MAX_TEXT});`,
  });
  return page;
}

const OPS = {
  async page() {
    return readPage(await activeTab());
  },
  async selection() {
    const page = await readPage(await activeTab());
    return { selection: page.selection, title: page.title, url: page.url };
  },
  async tabs() {
    const tabs = await browser.tabs.query({});
    return tabs.map(tabInfo);
  },
  async activate({ id }) {
    const tab = await browser.tabs.update(Number(id), { active: true });
    await browser.windows.update(tab.windowId, { focused: true });
    return tabInfo(tab);
  },
  async close({ id }) {
    const tab = id ? await browser.tabs.get(Number(id)) : await activeTab();
    await browser.tabs.remove(tab.id);
    return tabInfo(tab);
  },
  async find({ text }) {
    const tab = await activeTab();
    if (UNREADABLE.test(tab.url || "")) throw new Error("the browser doesn't let extensions search this page");
    const [found] = await browser.tabs.executeScript(tab.id, {
      code: `window.getSelection().removeAllRanges(); window.find(${JSON.stringify(String(text || ""))}, false, false, true);`,
    });
    return { found: !!found, title: tab.title };
  },
  async open({ url }) {
    const tab = await browser.tabs.create({ url: String(url) });
    return tabInfo(tab);
  },
};

async function reply(cfg, body) {
  try {
    await fetch(`http://127.0.0.1:${cfg.port}/reply`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Neon-Token": cfg.token },
      body: JSON.stringify(body),
    });
  } catch (e) {
    // NEON went away between asking and answering; it will time out on its side.
  }
}

async function run(cfg, req) {
  const op = OPS[req.op];
  if (!op) {
    await reply(cfg, { id: req.id, ok: false, error: `unknown request ${req.op}` });
    return;
  }
  try {
    const data = await op(req.args || {});
    await reply(cfg, { id: req.id, ok: true, data });
  } catch (e) {
    await reply(cfg, { id: req.id, ok: false, error: String((e && e.message) || e) });
  }
}

// ---- the long-poll loop ------------------------------------------------------------------------

async function browserName() {
  try {
    const info = await browser.runtime.getBrowserInfo();
    return info.name || "Firefox";
  } catch (e) {
    return "Firefox";
  }
}

async function loop() {
  const name = await browserName();
  for (;;) {
    const cfg = await settings();
    if (!cfg.token) {
      show("key");
      await sleep(4000);
      continue;
    }
    try {
      const res = await fetch(`http://127.0.0.1:${cfg.port}/poll`, {
        headers: { "X-Neon-Token": cfg.token, "X-Neon-Browser": name },
        cache: "no-store",
      });
      if (res.status === 403) {
        show("key");
        await sleep(4000);
        continue;
      }
      show("on");
      if (res.status === 200) {
        const req = await res.json();
        run(cfg, req);             // not awaited: the next poll starts straight away
      }
    } catch (e) {
      show("off");
      await sleep(3000);
    }
  }
}

browser.storage.onChanged.addListener(() => { state = ""; });
show("off");
loop();
